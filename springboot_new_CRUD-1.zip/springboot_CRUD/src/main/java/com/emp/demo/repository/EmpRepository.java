package com.emp.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.emp.demo.entity.Employee;

@Repository
public class EmpRepository {
	public List<Employee> employee=new ArrayList<Employee>();
	

	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		return employee;
	}

}
