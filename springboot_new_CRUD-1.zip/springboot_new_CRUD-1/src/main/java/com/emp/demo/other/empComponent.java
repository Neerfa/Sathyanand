package com.emp.demo.other;

import org.springframework.stereotype.Component;

@Component
public class empComponent {

}
