package com.marlabs.training.project;

interface MyInterface {
	void display();
}

public class RefernceMethod {

	public void myMethod() {
		System.out.println("Instance Method");
	}

	public static void main(String[] args) {
		RefernceMethod obj = new RefernceMethod();
		// Method reference using the object of the class
		MyInterface ref = obj::myMethod;
		// Calling the method of functional interface
		ref.display();
	}
}