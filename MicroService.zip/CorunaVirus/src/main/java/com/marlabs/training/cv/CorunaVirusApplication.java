package com.marlabs.training.cv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorunaVirusApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorunaVirusApplication.class, args);
	}

}
