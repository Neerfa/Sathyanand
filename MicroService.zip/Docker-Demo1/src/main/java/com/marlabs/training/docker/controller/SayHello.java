package com.marlabs.training.docker.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SayHello {
	
	@GetMapping
	public String  SayHelloBack(){
		return "Hi  docker user afreenbanu";
		
	}

}
